# AFPS S Website

Static Marathi NGO website for **आदिवासी फासे पारधी सुधार समिती**.

## GitHub Pages
1. Create a GitHub repository.
2. Upload all files/folders from this package.
3. Go to **Settings → Pages**.
4. Choose **Deploy from a branch**, branch `main`, folder `/ (root)`.
5. Save.
6. For `afpss.org.in`, add the custom domain in GitHub Pages and configure the DNS records at your domain registrar.

## Important
Replace the gallery placeholders with your real school/NGO photos. Update official phone number, registration details, student count, and other verified information before publishing.
